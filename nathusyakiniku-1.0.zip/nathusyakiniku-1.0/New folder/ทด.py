ll = [1,2,3,4,5]
rr = [5,4,3,2,1]
# for i in ll :
#     print(ll,ll.index(i))

#     print(rr[ll.index(i)])
import random
print(random.choice(ll))
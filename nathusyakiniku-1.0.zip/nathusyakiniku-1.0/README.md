# nathusyakiniku

Yakinuku by nathus jinnamo

Installation 1.clone repository git clone https://github.com/3393412/nathusyakiniku.git cd in repository 2.install envi python -m pip install in requirements 3.run game python proj3k.py

How to play pet your cow and grill meat if cow color is red you need to pet them afther that you click on dish the meat will pop then you grill meat and serve click on buy button to buy your cow click on add slot to get more cow slot you can deleted your un used meat by drag them on Trash There's 3 order type steak ,rice,soiju drag them to their cooking station your meat will shown as cooked ready to serve

UML diagram https://drive.google.com/file/d/136Fq-35GbRnFGsBonF4vwb1P5YsQLPu9/view?usp=drive_link 
Other sources 
https://youtu.be/iGPIkGipE-U
